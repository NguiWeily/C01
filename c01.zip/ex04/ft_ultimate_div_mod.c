/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/22 16:58:09 by wngui             #+#    #+#             */
/*   Updated: 2023/06/22 19:12:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = temp / *b;
	*b = temp % *b;
}
/*
int	main(void)
{
	int	a;
	int	b;

	a = 20;
	b = 7;
	printf("Before division: a = %d, b = %d\n", a, b);
	ft_ultimate_div_mod(&a, &b);
	printf("After division: a = %d, b = %d\n", a, b);
	return (0);
}*/
